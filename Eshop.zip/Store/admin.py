from django.contrib import admin
from .models import Product, Catagory, Customer, Order


class AdminProduct(admin.ModelAdmin):
    list_display = ['name', 'price', 'catagory']

class AdminCatagory(admin.ModelAdmin):
    list_display = ['name']



admin.site.register(Product, AdminProduct)
admin.site.register(Catagory, AdminCatagory)
admin.site.register(Customer)
admin.site.register(Order)


