from .views import Index, Signup, Login, logout, Cart, OrderView
from django.urls import path, include
from . import views





urlpatterns = [
    
    path('', Index.as_view(), name = 'homepage'),
    path('Signup',  Signup.as_view(), name='signup'),
    path('login',  Login.as_view(), name='login') ,
    path('logout',  logout, name='logout'),
    path('Cart', Cart.as_view(), name='cart'),
    path('Order',  OrderView.as_view(), name='order')
]